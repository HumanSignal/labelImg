Version: 1.0.3
new feature:
 - Press and hold key "T" to rotate without resize boxes selected
Install: run file install.bat
manual:
Install:
run cmd:
pip install -r requirements.txt

Usage:
Run file: labelImg.bat
or run cmd:
python labelImg.py [IMAGE_PATH] [PRE-DEFINED CLASS FILE]


reference source: https://github.com/heartexlabs/labelImg