Version: 1.0.0
Add feature:
 - "Ctrl + A" to select all
 - Allow mutlty select(hold key "ctrl" and select )
Install: run file install.bat
manual:
Install:
run cmd:
pip install -r requirements.txt

Usage:
Run file: labelImg.bat
or run cmd:
python labelImg.py [IMAGE_PATH] [PRE-DEFINED CLASS FILE]


reference source: https://github.com/heartexlabs/labelImg